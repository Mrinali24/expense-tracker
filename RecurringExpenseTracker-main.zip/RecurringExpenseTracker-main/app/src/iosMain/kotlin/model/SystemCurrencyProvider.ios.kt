package model

actual fun getSystemCurrencyCode(): String {
    // TODO: Retrieve system default currency
    return "USD"
}
